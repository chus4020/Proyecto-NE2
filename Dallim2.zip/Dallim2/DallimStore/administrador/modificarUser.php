<!DOCTYPE html>
<html lang="es">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Admin Dallin</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>
<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

  <?php include "menu.php";?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">
          <!-- Page Heading -->
          <?php
          $cosulta=ConsultarProducto($_GET["no"]);
          function ConsultarProducto($id_cur)
          {
            include "conexion.php";
            $sentencia="SELECT * FROM usuario WHERE id_usuario='".$id_cur."' ";
            $resultado=mysqli_query($conexion,$sentencia)or die(mysqli_error($conexion));
            $filas=mysqli_fetch_assoc($resultado);
            return[
              $filas['id_usuario'],
              $filas['nombre'],
              $filas['ap_pat'],
              $filas['ap_mat'],
              $filas['nombre_usuario'],
              $filas['contrasena'],
              $filas['correo'],
              $filas['telefono'],
              $filas['direccion'],
              $filas['fecha_nac']
            ];
          }
          ?>
          <h1 class="h3 mb-2 text-gray-800">Modificar Usuario</h1>
              <form action="atualizarUser.php" method="POST">
              <label class="control-label">Id &nbsp;&nbsp; <sup>*</sup></label><br/> 
			  <input type="text" placeholder="Nombre" name="id" value="<?php echo $cosulta[0] ?>"readonly><br/>
      <label class="control-label">Nombre &nbsp;&nbsp; <sup>*</sup></label><br/> 
			  <input type="text" placeholder="Nombre" name="nom" value="<?php echo $cosulta[1] ?>"required ><br/>
			<label class="control-label">Apellido Paterno&nbsp; &nbsp; <sup>*</sup></label><br/> 
			  <input type="text" placeholder="Apellido Paterno" name="pat" value="<?php echo $cosulta[2] ?>"required><br/> 
        <label class="control-label">Apellido Materno&nbsp; &nbsp; <sup>*</sup></label><br/> 
			  <input type="text" placeholder="Apellido Materno" name="mat" value="<?php echo $cosulta[3] ?>"><br/> 
			<label class="control-label">Usuario &nbsp; &nbsp; &nbsp; <sup>*</sup></label><br/> 
			  <input type="text"  name="usr" value="<?php echo $cosulta[4] ?>"required><br/> 
        <label class="control-label">Contraseña&nbsp; &nbsp; &nbsp; <sup>*</sup></label><br/> 
			  <input type="password"  name="pass" placeholder="*************" value="<?php echo $cosulta[5] ?>"required><br/> 
			<label class="control-label">Correo &nbsp; &nbsp;&nbsp; <sup>*</sup></label><br/> 
      <input type="email"  name="email" placeholder="example@gmail.com" value="<?php echo $cosulta[6] ?>"required><br/> 
			<label class="control-label">&nbsp;Telefono(10 Digitos)<sup>*</sup></label><br/> 
			  <input type="text" name="tel" placeholder="4491234567" pattern="[0-9]{10}"value="<?php echo $cosulta[7] ?>"required><br/> 
			<label class="control-label">&nbsp; Dirección <sup>*</sup></label><br/> 
			  <input type="text" name="dir" value="<?php echo $cosulta[8] ?>"required><br/> 
        <label class="control-label">&nbsp; Fecha Nacimiento <sup>*</sup></label><br/> 
			  <input type="date" name="nac" value="<?php echo $cosulta[9] ?>"required><br/> 
			<input type="submit" value="Actualizar"> 
	</form>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Your Website 2020</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/Ventas.js"></script>

</body>

</html>
