<?php
EliminarArticulo($_GET['no']);
function EliminarArticulo($id_articulo)
{
    include "conexion.php";
    $sentencia="DELETE FROM articulo WHERE id_articulo='".$id_articulo."' ";
    mysqli_query($conexion,$sentencia) or die (mysqli_error("Error al eliminar".$conexion));
}
?>

<script type="text/javascript">
alert("Articulo Eliminado");
window.location.href='articulos.php';
</script>