<?php
ActualizarArticulo($_POST['id'],$_POST['art'],$_POST['pre'],$_POST['mar'],$_POST['clor'],$_POST['exs'],$_POST['dcs'],$_POST['tll'],$_POST['ctg'],$_POST['ofr']);
function ActualizarArticulo($id_articulo,$articulo,$precio,$marca,$color,$exis,$des,$talla,$cate,$ofer){
include "conexion.php";
$sentencia="UPDATE articulo SET nombre_articulo='".$articulo."', precio='".$precio."', id_marca='".$marca."', color='".$color."', existencia='".$exis."', descripción='".$des."', id_talla='".$talla."',id_categoria ='".$cate."',id_oferta='".$ofer."' WHERE id_articulo='".$id_articulo."' ";
mysqli_query($conexion,$sentencia)or die(mysqli_error("Error al actualizar datos".$conexion));
}
?>

<script type="text/javascript">
alert("Exito al modificar el articulo");
window.location.href='articulos.php';
</script>