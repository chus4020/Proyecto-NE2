<?php
	$conexion=new mysqli("localhost","root","","dallim2");
	if(mysqli_connect_errno())
	{
		printf("Fallo la Conexion");
	}else
	?>