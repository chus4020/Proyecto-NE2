<!DOCTYPE html>
<html lang="es">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Admin Dallin</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>
<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
        
        <div class="sidebar-brand-text mx-3">
          <p>Admin&nbsp;</p>
          <p><b> E-CurseViness</b><br>
          </p>
        </div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item active"> <a class="nav-link" href="index.php"> <i class="fas fa-fw fa-dollar-sign"></i> <span>Ingresos</span></a></li>
      <li class="nav-item active">&nbsp;</li>
      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        Graficas
      </div>

      <!-- Visitas -->
      <li class="nav-item">
        <a class="nav-link" href="visitas.php">
          <i class="fas fa-fw fa-chart-bar"></i>
          <span>Visitas</span></a>
      </li>

      <!-- Ventas -->
      <li class="nav-item">
        <a class="nav-link" href="ventas.php">
          <i class="fas fa-fw fa-chart-bar"></i>
          <span>&nbsp;Top Ventas</span></a>
      </li>
		
		<!-- Cupones -->
      <li class="nav-item">
        <a class="nav-link" href="cupones.php">
          <i class="fas fa-fw fa-chart-line"></i>
          <span>&nbsp;Cupones</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Nav Item - Charts -->
      <div class="sidebar-heading">
        Acciones
      </div>

      <!-- Agregar Curso -->
      <li class="nav-item">
        <a class="nav-link" href="cursos.php">
          <i class="fas fa-fw fa-book"></i>
          <span>Cursos&nbsp;</span></a>
      </li>
		
		<!-- Agregar Cupon -->
      <li class="nav-item">
        <a class="nav-link" href="agregarcupon.php">
          <i class="fas fa-fw fa-ticket-alt"></i>
          <span>Agregar Cupon&nbsp;</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">
          <!-- Page Heading -->
          <?php
          $cosulta=ConsultarProducto($_GET["no"]);
          function ConsultarProducto($id_cur)
          {
            include "conexion.php";
            $sentencia="SELECT * FROM articulo WHERE id_articulo='".$id_cur."' ";
            $resultado=mysqli_query($conexion,$sentencia)or die(mysqli_error($conexion));
            $filas=mysqli_fetch_assoc($resultado);
            return[
              $filas['id_articulo'],
              $filas['nombre_articulo'],
              $filas['precio'],
              $filas['id_marca'],
              $filas['color'],
              $filas['existencia'],
              $filas['descripción'],
              $filas['id_talla'],
              $filas['id_categoria'],
              $filas['id_oferta']
            ];
          }
          ?>
          <h1 class="h3 mb-2 text-gray-800">Modificar Articulo</h1>
              <form action="atualizarArt.php" method="POST">
              <label class="control-label">Id Articulo&nbsp;&nbsp; <sup>*</sup></label><br/> 
			  <input type="number" placeholder="00" name="id" required value="<?php echo $cosulta[0] ?>"readonly><br/> 
  <label class="control-label">Articulo&nbsp;&nbsp; <sup>*</sup></label><br/> 
			  <input type="text" placeholder="Nombre" name="art" required value="<?php echo $cosulta[1] ?>"><br/>
			<label class="control-label">Precio&nbsp; &nbsp; <sup>*</sup></label><br/> 
			  <input type="number" placeholder="$$$$" name="pre" required value="<?php echo $cosulta[2] ?>"><br/> 
              <label class="control-label">Marca&nbsp; &nbsp; <sup>*</sup></label><br/> 
			  <input type="number" name="mar" required value="<?php echo $cosulta[3] ?>"><br/> 
			<label class="control-label">Color&nbsp; &nbsp; &nbsp; <sup>*</sup></label><br/> 
			  <input type="text"  name="clor" required value="<?php echo $cosulta[4] ?>"><br/> 
        <label class="control-label">Existencia&nbsp; &nbsp; &nbsp; <sup>*</sup></label><br/> 
			  <input type="number"  name="exs" required value="<?php echo $cosulta[5] ?>"><br/> 
			<label class="control-label">Descripción&nbsp; &nbsp;&nbsp; <sup>*</sup></label><br/> 
      <textarea name="dcs" cols="30" rows="10" placeholder="Descripción" required maxlength="200"><?php echo $cosulta[6]?></textarea><br/>
			<label class="control-label">&nbsp;Talla<sup>*</sup></label><br/> 
			  <input type="number" name="tll" required value="<?php echo $cosulta[7] ?>"><br/> 
			<label class="control-label">&nbsp; Categoria <sup>*</sup></label><br/> 
			  <input type="number" name="ctg" required value="<?php echo $cosulta[8] ?>"><br/> 
        <label class="control-label">&nbsp; Oferta <sup>*</sup></label><br/> 
			  <input type="number" name="ofr" required value="<?php echo $cosulta[9] ?>"><br/> 
			<input type="submit" value="Actualizar"> 
	</form>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Your Website 2020</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/Ventas.js"></script>

</body>

</html>
