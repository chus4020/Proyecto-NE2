<?php
session_start();

include_once 'conexion/conexion.php';
$objeto = new Conexion();


?>