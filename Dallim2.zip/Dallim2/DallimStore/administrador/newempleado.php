<?php
include "conexion.php";
if (isset($_POST['ape'])&& !empty($_POST['ape'])&& isset($_POST['nom'])&& !empty($_POST['nom'])&& 
isset($_POST['usr'])&& !empty($_POST['usr'])&& isset($_POST['tel'])&& !empty($_POST['tel'])&&
isset($_POST['email'])&& !empty($_POST['email'])&& isset($_POST['pass'])&& !empty($_POST['pass'])&&
isset($_POST['tkn'])&& !empty($_POST['tkn']))
{
    $sentencia="INSERT INTO empleado(apellidos, nombre, nombreUS, telefono, correo, passEmp, token)  values ('$_POST[ape]', '$_POST[nom]', '$_POST[usr]', '$_POST[tel]', '$_POST[email]', '$_POST[pass]', '$_POST[tkn]')";
    mysqli_query($conexion,$sentencia) or die ("Problema conectando con la bd");
}
?>
<script type="text/javascript">
alert("Empleado registrado con exito");
window.location.href='empleados.php';
</script>