<?php
include "conexion.php";
if (isset($_POST['codigo'])&& !empty($_POST['codigo'])&& isset($_POST['cpon'])&& !empty($_POST['cpon'])&&
isset($_POST['estado'])&& !empty($_POST['estado']))
{ 
    $sentencia="insert into cupones (Codigo_Cupon,Cupon,Estatus) values ('$_POST[codigo]', '$_POST[cpon]', '$_POST[estado]')";
    mysqli_query($conexion,$sentencia)or die ("Problema conectando con la bd");
}
?>
<script type="text/javascript">
alert("Exito al regitrar el cupon");
window.location.href='agregarcupon.php';
</script>