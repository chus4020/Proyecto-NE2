<?php
ActualizarEmpleado($_POST['id'],$_POST['ape'],$_POST['nom'],$_POST['usr'],$_POST['tel'],$_POST['email'],$_POST['pass'],$_POST['tkn']);
function ActualizarEmpleado($id_empleado,$apel,$nomb,$usuar,$tele,$mail,$passw,$tokn){
include "conexion.php";
$sentencia="UPDATE empleado SET apellidos='".$apel."', nombre='".$nomb."', nombreUS='".$usuar."', telefono='".$tele."', correo='".$mail."', passEmp='".$passw."', token='".$tokn."' WHERE id_empleado='".$id_empleado."' ";
mysqli_query($conexion,$sentencia)or die(mysqli_error("Error al actualizar datos".$conexion));
}
?>

<script type="text/javascript">
alert("Exito al modificar el articulo");
window.location.href='empleados.php';
</script>