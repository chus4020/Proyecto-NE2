<?php
EliminarUsuario($_GET['no']);
function EliminarUsuario($id_usuario)
{
    include "conexion.php";
    $sentencia="DELETE FROM usuario WHERE id_usuario='".$id_usuario."' ";
    mysqli_query($conexion,$sentencia) or die (mysqli_error("Error al eliminar".$conexion));
}
?>

<script type="text/javascript">
alert("Usuario Eliminado");
window.location.href='usuarios.php';
</script>