<?php
include "conexion.php";
if (isset($_POST['nom'])&& !empty($_POST['nom'])&& isset($_POST['pat'])&& !empty($_POST['pat'])&& 
isset($_POST['usr'])&& !empty($_POST['usr'])&& isset($_POST['pass'])&& !empty($_POST['pass'])&&
isset($_POST['email'])&& !empty($_POST['email'])&& isset($_POST['tel'])&& !empty($_POST['tel'])&&
isset($_POST['dir'])&& !empty($_POST['dir'])&&isset($_POST['nac'])&& !empty($_POST['nac']))
{
    $sentencia="insert into usuario(nombre, ap_pat, ap_mat, nombre_usuario, contrasena, correo, telefono, direccion, fecha_nac)  values ('$_POST[nom]', '$_POST[pat]', '$_POST[mat]', '$_POST[usr]', '$_POST[pass]', '$_POST[email]', '$_POST[tel]', '$_POST[dir]', '$_POST[nac]')";
    mysqli_query($conexion,$sentencia) or die ("Problema conectando con la bd");
}
?>
<script type="text/javascript">
alert("Usuario registrado con exito");
window.location.href='usuarios.php';
</script>