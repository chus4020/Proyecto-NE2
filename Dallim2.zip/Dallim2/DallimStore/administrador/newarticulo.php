<?php
include "conexion.php";
if (isset($_POST['id'])&& !empty($_POST['id'])&& isset($_POST['art'])&& !empty($_POST['art'])&&
isset($_POST['pre'])&& !empty($_POST['pre'])&& isset($_POST['mar'])&& !empty($_POST['mar'])&&
isset($_POST['clor'])&& !empty($_POST['clor'])&& isset($_POST['exs'])&& !empty($_POST['exs'])&&
isset($_POST['dcs'])&& !empty($_POST['dcs'])&& isset($_POST['tll'])&& !empty($_POST['tll'])&&
isset($_POST['ctg'])&& !empty($_POST['ctg'])&&isset($_POST['ofr'])&& !empty($_POST['ofr']))
{
    $sentencia="INSERT INTO articulo (id_articulo,nombre_articulo,precio,id_marca,color,existencia,descripción,id_talla,id_categoria,id_oferta) values ('$_POST[id]', '$_POST[art]', '$_POST[pre]', '$_POST[mar]', '$_POST[clor]', '$_POST[exs]', '$_POST[dcs]', '$_POST[tll]', '$_POST[ctg]', '$_POST[ofr]')";
    mysqli_query($conexion,$sentencia) or die ("Problema conectando con la bd");
}
?>
<script type="text/javascript">
alert("Exito al regitrar el articulo");
window.location.href='articulos.php';
</script>