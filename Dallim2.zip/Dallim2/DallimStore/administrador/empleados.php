<!DOCTYPE html>
<html lang="es">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Admin Dallin</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>
<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <?php include "menu.php";?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">
        <h1 class="h3 mb-2 text-gray-800">Empleados Disponibles</h1>
          <!-- Page Heading -->
          <table border="1">
          <tr>
          <td>ID</td>
          <td>Apellidos</td>
          <td>Nombre</td>
          <td>Usuario</td>
          <td>Telefono</td>
          <td>Correo</td>
          <td>Contraseña</td>
          <td>Token</td>
          <th> <a href="nuevoempleado.php"> <button type="button" class="btn btn-info">Nuevo</button> </a> </th>
          </tr>
          <?php
  include "conexion.php";
  $sentencia = "SELECT * FROM empleado";
	$resultado=mysqli_query($conexion,$sentencia)or die(mysqli_error($conexion));
	while($filas=mysqli_fetch_array($resultado)){
        echo "<tr>";
        echo "<td>"; echo $filas['id_empleado']; echo "</td>";
        echo "<td>"; echo $filas['apellidos']; echo "</td>";
        echo "<td>"; echo $filas['nombre']; echo "</td>";
        echo "<td>"; echo $filas['nombreUS']; echo "</td>";
        echo "<td>"; echo $filas['telefono']; echo "</td>";
        echo "<td>"; echo $filas['correo']; echo "</td>";
        echo "<td>"; echo $filas['passEmp']; echo "</td>";
        echo "<td>"; echo $filas['token']; echo "</td>";
        echo "<td>  <a href='modificarEmp.php?no=".$filas['id_empleado']."'> <button type='button' class='btn btn-success'>Modificar</button> </a> </td>";
        echo "<td> <a href='eliminarEmp.php?no=".$filas['id_empleado']."''><button type='button' class='btn btn-danger'>Eliminar</button></a> </td>";
	    echo "</tr>";
	}
	?>

          </table>

          <!-- Content Row -->
          <div class="row">

            <div class="col-xl-8 col-lg-7">

              <!-- Area Chart -->
              <!-- Bar Chart -->
              <div class="well">
</div>

            </div>

          <!-- Donut Chart -->          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Your Website 2020</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/Ventas.js"></script>

</body>

</html>
