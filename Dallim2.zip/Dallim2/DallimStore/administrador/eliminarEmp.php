<?php
EliminarEmpleado($_GET['no']);
function EliminarEmpleado($id_empleado)
{
    include "conexion.php";
    $sentencia="DELETE FROM empleado WHERE id_empleado='".$id_empleado."' ";
    mysqli_query($conexion,$sentencia) or die (mysqli_error("Error al eliminar".$conexion));
}
?>

<script type="text/javascript">
alert("Empleado Eliminado");
window.location.href='empleados.php';
</script>