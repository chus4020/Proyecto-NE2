<?php
ActualizarUsuario($_POST['id'],$_POST['nom'],$_POST['pat'],$_POST['mat'],$_POST['usr'],$_POST['pass'],$_POST['email'],$_POST['tel'],$_POST['dir'],$_POST['nac']);
function ActualizarUsuario($id_usuario,$nombre,$paterno,$materno,$usuar,$passw,$mail,$tele,$dire,$naci){
include "conexion.php";
$sentencia="UPDATE usuario SET nombre='".$nombre."', ap_pat='".$paterno."', ap_mat='".$materno."', nombre_usuario='".$usuar."', contrasena='".$passw."', correo='".$mail."', telefono='".$tele."',direccion ='".$dire."',fecha_nac='".$naci."' WHERE id_usuario='".$id_usuario."' ";
mysqli_query($conexion,$sentencia)or die(mysqli_error("Error al actualizar datos".$conexion));
}
?>

<script type="text/javascript">
alert("Exito al modificar el articulo");
window.location.href='usuarios.php';
</script>