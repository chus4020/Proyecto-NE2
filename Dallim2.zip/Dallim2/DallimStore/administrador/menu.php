<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
        
        <div class="sidebar-brand-text mx-3">
          <p>Admin&nbsp;</p>
          <p><b> Dallin</b><br>
          </p>
        </div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item active"> <a class="nav-link" href="index.php"> <i class="fas fa-fw fa-dollar-sign"></i> <span>Ingresos</span></a></li>
      <li class="nav-item active">&nbsp;</li>
      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        Graficas
      </div>

      <!-- Ventas -->
      <li class="nav-item">
        <a class="nav-link" href="ventas.php">
          <i class="fas fa-fw fa-chart-bar"></i>
          <span>&nbsp;Top Ventas</span></a>
      </li>
		
      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Nav Item - Charts -->
      <div class="sidebar-heading">
        Acciones
      </div>

      <!-- Agregar Curso -->
      <li class="nav-item">
        <a class="nav-link" href="articulos.php">
          <i class="fas fa-fw fa-book"></i>
          <span>Articulos&nbsp;</span></a>
      </li>
		
		<!-- Agregar Cupon -->
      <li class="nav-item">
        <a class="nav-link" href="usuarios.php">
          <i class="fas fa-fw fa-user-alt"></i>
          <span>Usuarios&nbsp;</span></a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="empleados.php">
          <i class="fas fa-fw fa-user-alt"></i>
          <span>Empleados&nbsp;</span></a>
      </li>
      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>
    </ul>
    